using System;

namespace CheckPoint.Models
{
    public class ComentarioModel
    {
        public int Id { get; set; }
        
        public string Nome { get; set; }

        public string Email { get; set; }

        public string Comentario { get; set; }

        public DateTime DataCriacao { get; set; }

        public bool Status { get; set; }
    public ComentarioModel(){
        
    }

    public ComentarioModel (string nome, string comentario){
        this.Nome = nome;
        this.Comentario = comentario;
    }

    public ComentarioModel (int id, string nome, string email, string comentario, DateTime data, bool status){
        this.Id = id;
        this.Nome = nome;
        this.Email = email;
        this.Comentario = comentario;
        this.DataCriacao = data;
        this.Status = status;
    }

    }
}