using System;

namespace CheckPoint.Models {
    [Serializable]
    public class UsuarioModel {
        public int Id { get; set; }

        public string Nome { get; set; }

        public string Email {get; set;}

        public string Senha { get; set; }
    
        public string Ssenha { get; set; }

        public UsuarioModel(int id, string email, string senha, string nome, string ssenha)
        {
            this.Id = Id;
            this.Nome = nome;
            this.Email = email;
            this.Senha = senha;
            this.Ssenha = ssenha;
        }

        public UsuarioModel(string email, string senha)
        {
            Email = email;
            Senha = senha;
        }
        public UsuarioModel(string nome, string email, string senha, string ssenha)
        {
            this.Nome = nome;
            this.Email = email;
            this.Senha = senha;
            this.Ssenha = ssenha;
        }
    }
}