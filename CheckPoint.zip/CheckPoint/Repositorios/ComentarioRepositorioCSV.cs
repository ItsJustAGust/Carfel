using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using CheckPoint.Interfaces;
using CheckPoint.Models;

namespace CheckPoint.Repositorios
{
    public class ComentarioRepositorioCSV : IComentario
    {
        public ComentarioModel Comentar (ComentarioModel comentarios){
            if (File.Exists ("comentarios.csv"))
            {
                comentarios.Id = System.IO.File.ReadAllLines ("comentarios.csv").Length +1;
            }
            else
            {
                comentarios.Id = 1;
            }
            using (StreamWriter sw = new StreamWriter ("comentarios.csv", true))
            {
                sw.WriteLine($"{comentarios.Id};{comentarios.Nome};{comentarios.Email};{comentarios.Comentario};{DateTime.Now};{false}");
            }
            return comentarios;
        }

        public List<ComentarioModel> Listar() => ListaCSVcm();

        private List<ComentarioModel> ListaCSVcm(){
            List<ComentarioModel> lsComentario = new List<ComentarioModel> ();

            if (!File.Exists ("comentarios.csv"))
            {
                return lsComentario;
            }
            string[] linhas = File.ReadAllLines ("comentarios.csv");

            foreach (string linha in linhas)
            {
                if (string.IsNullOrEmpty(linha))
                {
                    continue;
                }
                string[] Dados = linha.Split(";");

                ComentarioModel comentarios = new ComentarioModel(
                    id: int.Parse(Dados[0]),
                    nome: Dados[1],
                    email: Dados[2],
                    comentario: Dados[3],
                    data:DateTime.Parse(Dados[4]),
                    status: bool.Parse(Dados[5])
                );
                lsComentario.Add (comentarios);
            } 
            return lsComentario;
        }
        public List<ComentarioModel> Aprovados(){
            List<ComentarioModel> ComentariosAprovados = new List<ComentarioModel>();
            if (!File.Exists("comentarios.csv"))
            {
                return ComentariosAprovados;
            }
            string[] linhas = File.ReadAllLines("comentarios.csv");

            foreach (string linha in linhas)
            {
                if (string.IsNullOrEmpty (linha))
                {
                    continue;
                }            
                string[] Dados = linha.Split(";");

                ComentarioModel comentarios = new ComentarioModel(
                    id: int.Parse(Dados[0]),
                    nome: Dados[1],
                    email:Dados[2],
                    comentario:Dados[3],
                    data:DateTime.Parse(Dados[4]),
                    status:bool.Parse(Dados[5])
                );
                if (comentarios.Status == true)
                {
                    ComentariosAprovados.Add (comentarios);
                }
            }
            return ComentariosAprovados.OrderBy(x=> x.DataCriacao).Reverse ().ToList();
        }
        public void Aprovar (int id){
            //segundo a candy: abre o stream do arquivo
            string[] linhas = File.ReadAllLines("coentarios.csv");

            //segundo o codigo que a candy copiou: Lê cada registro do CSV
            for (int i = 0; i <linhas.Length; i++)
            {
                string[] dadosDaLinha = linhas[i].Split(";");
                if (id.ToString() == dadosDaLinha[0])
                {
                    linhas[i] = ($"{dadosDaLinha[0]};{dadosDaLinha[1]};{dadosDaLinha[2]};{dadosDaLinha[3]};{dadosDaLinha[4]};{true}");
                    break;
                }
            }
            File.WriteAllLines ("comentarios.csv", linhas);
        }
        public void Rejeitar(int id){
              string[] linhas = File.ReadAllLines("coentarios.csv");

            //segundo o codigo que a candy copiou: Lê cada registro do CSV
            for (int i = 0; i <linhas.Length; i++)
            {
                string[] dadosDaLinha = linhas[i].Split(";");
                if (id.ToString() == dadosDaLinha[0])
                {
                    linhas[i] = ($"{dadosDaLinha[0]};{dadosDaLinha[1]};{dadosDaLinha[2]};{dadosDaLinha[3]};{dadosDaLinha[4]};{false}");
                    break;
                }
            }
            File.WriteAllLines ("comentarios.csv", linhas);
        }
    }
}