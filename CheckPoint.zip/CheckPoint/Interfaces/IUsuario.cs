using System.Collections.Generic;
using CheckPoint.Models;

namespace CheckPoint.Interfaces {
    public interface IUsuario {
        UsuarioModel Cadastrar (UsuarioModel usuario);

        UsuarioModel BuscarId (int Id);
        List<UsuarioModel> Listar ();

        UsuarioModel BuscarPorEmailESenha (string email, string senha);
    }
}