using System.Collections.Generic;
using CheckPoint.Models;

namespace CheckPoint.Interfaces
{
    public interface IComentario
    {
        
        ComentarioModel Comentar (ComentarioModel comentarios);

        List<ComentarioModel> Listar();

        void Aprovar(int id);

        void Rejeitar(int id);

        List<ComentarioModel> Aprovados();
        
    }
}