using System;
using CheckPoint.Interfaces;
using CheckPoint.Models;
using CheckPoint.Repositorios;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace CheckPoint.Controllers
{
    public class ComentariosController : Controller
    {
        public IComentario ComentarioRepositorioCSV{get; set;}

        public ComentariosController(){
            ComentarioRepositorioCSV = new ComentarioRepositorioCSV();
        }
        [HttpGet]
        public IActionResult Comentar(){
            string id = HttpContext.Session.GetString("idUsuario");
            if (id != null)
            {
                int idInt = int.Parse(id);
                UsuarioRepositorio usuarioRep = new UsuarioRepositorio();
                UsuarioModel usuario = usuarioRep.BuscarId (idInt);

            }
            return View();
        }
        [HttpPost]
        public IActionResult Comentar (IFormCollection form)
        {
            if (HttpContext.Session.GetString ("nomeUsuario") == null)
            {
                return RedirectToAction("Usuario", "Login");
            }
            String Nome = HttpContext.Session.GetString ("nomeUsuario");

            ComentarioModel ComentarioModel = new ComentarioModel (nome: Nome, comentario: form["comentario"]);

            ComentarioRepositorioCSV.Comentar(ComentarioModel);

            return View();
        }
        public IActionResult Listar(){
            String Email = HttpContext.Session.GetString ("emailUsuario");

            if (Email == "admin@carfel.com")
            {
                ViewData["Comentarios"] = ComentarioRepositorioCSV.Listar();
            }
            return View();
        }
        [HttpGet]
        public IActionResult Aprovar (int id){
            ComentarioRepositorioCSV Comentario = new ComentarioRepositorioCSV();
            Comentario.Aprovar(id);

            TempData["Aprovar"] = "Comentário Aprovado";
            return RedirectToAction ("Listar", "Comentarios");
        }
        public IActionResult Rejeitar(int id)
        {
            ComentarioRepositorioCSV Comentario = new ComentarioRepositorioCSV();
            Comentario.Rejeitar(id);

            TempData["Rejeitar"] = "Comentário Regeitado";

            return RedirectToAction ("Listar","Comentarios");
        }
    }
}