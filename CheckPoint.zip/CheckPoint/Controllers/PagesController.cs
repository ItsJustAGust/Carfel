using Microsoft.AspNetCore.Mvc;

namespace CheckPoint.Controllers 
{
    public class PagesController : Controller
    {
        [HttpGet]
        public IActionResult Home(){
            return View();
        }

        public IActionResult Formulario(){
            return View();
        }
        public IActionResult Planos(){
            return View();
        }
        public IActionResult SobreNos(){
            return View();
        }
        
    }
}